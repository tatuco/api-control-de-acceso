<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateVehiclesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vehicles', function (Blueprint $table) {
//            $table->increments('id');
            $table->string('plate',10)->unique();
            $table->boolean('active')->default(true);
            $table->integer('mod_id');
            $table->string('owner_id');
            $table->integer('code_id');
            $table->integer('acc_id');
            $table->integer('typ_id');
            $table->timestamps();

            $table->primary('plate');
            $table->foreign('mod_id')->references('mod_id')->on('models_vehicles');
            $table->foreign('owner_id')->references('dni')->on('persons');
            $table->foreign('code_id')->references('id')->on('codes');
            $table->foreign('typ_id')->references('id')->on('types');
            $table->foreign('acc_id')->references('acc_id')->on('accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vehicles');
    }
}

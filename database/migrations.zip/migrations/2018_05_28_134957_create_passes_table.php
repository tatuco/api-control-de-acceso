<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePassesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('passes', function (Blueprint $table) {
            $table->increments('id');
            $table->date('date_sta');
            $table->date('date_end');
            $table->boolean('active')->default(true);
            $table->string('host_id');
            $table->string('guest_id');
            $table->integer('sch_id');
            $table->integer('code_id');
            $table->integer('acc_id');
            $table->timestamps();


            $table->foreign('host_id')->references('dni')->on('persons');
            $table->foreign('guest_id')->references('dni')->on('persons');
            $table->foreign('sch_id')->references('id')->on('schedules');
            $table->foreign('code_id')->references('id')->on('codes');
            $table->foreign('acc_id')->references('acc_id')->on('accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pass');
    }
}

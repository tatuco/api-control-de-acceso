<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAssignmentVehiclesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assignment_vehicles', function (Blueprint $table) {
            $table->increments('id');
            $table->date('date_sta');
            $table->date('date_end');
            $table->boolean('active');
            $table->string('veh_pla');
            $table->string('per_id');
            $table->integer('acc_id');

            $table->timestamps();

            $table->foreign('veh_pla')->references('plate')->on('vehicles');
            $table->foreign('per_id')->references('dni')->on('persons');
            $table->foreign('acc_id')->references('acc_id')->on('accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('assignment_vehicle');
    }
}

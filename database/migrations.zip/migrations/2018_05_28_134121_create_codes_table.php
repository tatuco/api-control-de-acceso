<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCodesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('codes', function (Blueprint $table) {
            $table->increments('id');
            $table->text('code');
            $table->uuid('uuid');
            $table->boolean('active')->default(true);
            $table->integer('typ_id');
            $table->integer('sta_id');
            $table->integer('acc_id');
            $table->timestamps();

            $table->foreign('typ_id')->references('id')->on('types');
            $table->foreign('sta_id')->references('id')->on('status');
            $table->foreign('acc_id')->references('acc_id')->on('accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('codes');
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateParkingSectionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('parking_sections', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('places');
            $table->integer('available');
            $table->boolean('active')->default(true);
            $table->integer('park_id');
            $table->integer('acc_id');
            $table->timestamps();

            $table->foreign('park_id')->references('id')->on('parkings');
            $table->foreign('acc_id')->references('acc_id')->on('accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('parking_sections');
    }
}

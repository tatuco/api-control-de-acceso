<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDivicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('divices', function (Blueprint $table) {
            $table->increments('id');
            $table->string('location');
            $table->string('code');
            $table->string('ip');
            $table->boolean('active')->default(true);
            $table->integer('typ_id');
            $table->integer('acc_id');
            $table->timestamps();

            $table->foreign('typ_id')->references('id')->on('types');
            $table->foreign('acc_id')->references('acc_id')->on('accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('divices');
    }
}

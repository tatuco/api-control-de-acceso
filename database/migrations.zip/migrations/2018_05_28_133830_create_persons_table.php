<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePersonsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('persons', function (Blueprint $table) {

            $table->string('dni');
            $table->string('email');
            $table->string('name');
            $table->string('last_name');
            $table->string('phone');
            $table->text('address');
            $table->boolean('active')->default(true);
            $table->integer('typ_id');
            $table->integer('sta_id');
            $table->integer('acc_id');
            $table->timestamps();

            $table->primary('dni');
            $table->foreign('typ_id')->references('id')->on('types');
            $table->foreign('sta_id')->references('id')->on('status');
            $table->foreign('acc_id')->references('acc_id')->on('accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('persons');
    }
}
